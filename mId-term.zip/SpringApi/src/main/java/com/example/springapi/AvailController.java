package com.example.springapi;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AvailController {

    @CrossOrigin
    @RequestMapping("/hello")
    public MsgResponse sayHelloFromApi() {
        String msg = "Hello, I am from Spring API";
        MsgResponse response = new MsgResponse();
        response.setMsg(msg);
        return response;

    }


}